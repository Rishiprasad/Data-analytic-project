# Property-Management-System

Property Management System using java.

This system incorporates muliple user interfaces.

Java code is located in the "scr" folder and just click on any file to view the code from that file.

The main user interface file is the HomeScreenGUI.java file
